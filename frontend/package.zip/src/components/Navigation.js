import React from 'react';

const Navigation = ({
    currentIndex,
    totalQuestions,
    onPrevious,
    onNext,
    isLastQuestion
}) => {
    return (
        <div className="navigation">
            <button
                onClick={onPrevious}
                className="btn btn-secondary"
                disabled={currentIndex === 0}
                style={{ minWidth: '120px' }}
            >
                ← Previous
            </button>

            <div className="question-counter">
                {currentIndex + 1} of {totalQuestions}
            </div>

            <button
                onClick={onNext}
                className={isLastQuestion ? 'btn btn-success' : 'btn btn-primary'}
                style={{ minWidth: '120px' }}
            >
                {isLastQuestion ? 'Submit Quiz' : 'Next →'}
            </button>
        </div>
    );
};

export default Navigation;
